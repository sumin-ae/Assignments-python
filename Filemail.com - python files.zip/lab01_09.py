'''Write a Python program to remove elements from a list that are also present
in another list. '''
list=[1,2,3,4,5,6,7,8,9,10]
list1=[1,2,3,4,5] 

for i in range(10): 
    if (list1[i]==list[i]): 
        list.remove[i]

print(f"The reedited list is ")