
prime_set = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47}

user_input = int(input("Enter a number to check: "))

# Check if the number is in the set
if user_input in prime_set:
    print(f"{user_input} is a prime number in the set.")
else:
    print(f"{user_input} is not in the prime number set.")
